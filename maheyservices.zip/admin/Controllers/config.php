<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 03/11/18
 * Time: 11:38 PM
 */
    $con = mysqli_connect("localhost","root","","maheyservices");
    if (!$con)
    {
        echo mysqli_connect_error();
        die();
    }


?>