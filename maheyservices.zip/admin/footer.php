<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 7/21/2017
 * Time: 11:43 AM
 */
?>
<!-- footer content -->
<footer>
    <div class="pull-right">
        Admin Panel! &ensp;©2018 All Rights Reserved.
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>


<!-- Bootstrap -->
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- NProgress -->
<script src="vendors/nprogress/nprogress.js"></script>
<!-- bootstrap-progressbar -->
<script src="vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- Data Tables -->
<script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<!-- Custom Theme Scripts -->
<script src="build/js/custom.min.js"></script>

<script src="vendors/js/fetchData.js"></script>

<script src="vendors/js/tgetData.js.js"></script>

</body>
</html>

